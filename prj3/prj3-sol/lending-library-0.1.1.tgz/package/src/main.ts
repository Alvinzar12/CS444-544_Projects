import { readJson } from 'cs544-node-utils';
import { Errors } from 'cs544-js-utils';

import {LendingLibrary, makeLendingLibrary as makeLibrary}
  from './lib/lending-library.js';
import {makeLibraryDao, LibraryDao } from './lib/library-dao.js';
import * as Lib from './lib/library.js';

/*************************** Top-Level Code ****************************/


type DaoArg =
  string //mongourl
  | LibraryDao;

async function makeLendingLibrary(daoArg: DaoArg, paths: string[] = [])
  : Promise<Errors.Result<LendingLibrary>>
{
  let dao;
  if (typeof daoArg === 'string') {
    const daoResult = await makeLibraryDao(daoArg);
    if (!daoResult.isOk) return daoResult as Errors.Result<LendingLibrary>;
    dao = daoResult.val;
  }
  else {
    dao = daoArg;
  }
  const library = makeLibrary(dao);  
  for (const path of paths) {
    const readResult = await readJson(path);
    if (!readResult.isOk) return readResult as Errors.Result<LendingLibrary>;
    const books = readResult.val;
    for (const book of books) {
      const addResult = await library.addBook(book);
      if (!addResult.isOk) return addResult as Errors.Result<LendingLibrary>;
    }
  }
  return Errors.okResult(library);
}

export {
  LendingLibrary,
  makeLendingLibrary,
  //for testing
  makeLibraryDao,
  LibraryDao,
  Lib,
};
